instruction_time = 0.25 # Time taken per instruction.
debug = False          # Define whether the program should be run in `debug` mode.
N = 4                  # Define N to represent an n-way superscalar design.
